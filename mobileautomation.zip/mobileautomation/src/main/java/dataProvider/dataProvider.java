package dataProvider;


public class dataProvider {

    static String DEVICE_NAME = "Pixel XL API 29";
    static String AUTOMATION_NAME="uiautomator2";
    static String URL="http://127.0.0.1:4723/wd/hub";
    static String APP="app-release.apk";
    static String PATH="src";


   //Validations
    static String card_Value="NZ, 3";
    static String CSAT="CSAT";
    static String inputText="Input has been disabled.";
    static String email="nngg@rakuten.com";
    static String password="nipuni1982";
    static String msgWelcome="Welcome nngg tt";
    static String msgLogOut="You have been logged out.";
    static String option="Option1";
    static String input="チ";
    static String outputTxt="いつから予約できるか";



    public static String DEVICE_NAME() {
        return DEVICE_NAME;
    }

    public static String AUTOMATION_NAME(){
        return AUTOMATION_NAME;
    }

    public static String URL(){
        return URL;
    }

    public static String card_Value(){
        return card_Value;
    }

    public static String CSAT(){
        return CSAT;
    }

    public static String inputText(){
        return inputText;
    }

    public static String email(){
        return email;
    }

    public static String password(){
        return password;
    }

    public static String msgWelcome(){
        return msgWelcome;
    }

    public static String msgLogOut(){
        return msgLogOut;
    }

    public static String option(){
        return option;
    }

    public static String input(){
        return input;
    }

    public static String outputTxt(){
        return outputTxt;
    }

    public static String APP(){return APP;}

    public static String PATH(){return PATH;}
}