const form = document.forms[0];

form.addEventListener("submit", event => {
  event.preventDefault();
});
