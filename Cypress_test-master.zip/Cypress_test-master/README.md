# Cypress_test
You need to install cypress $npm install cypress --save-dev

Need to have node modules also installed.

Check and run the sample_test.js in the examples folder.

