# mobileautomation

Download Java and set Java_Home in environmental variables
Download Android STUDIO from below link
https://developer.android.com/studio/index.html
Check Android installation path in Machine
Set Android_Home Environmental variables path to SDK location and include bin folder paths in PATH variable

Open Android Studio and configure Virtual device/Emulator

Open Emulator and check if it is working.
Download Node.js                                                                                                                        
https://nodejs.org/en/download/
Set Node_Home Environmental variables path
Set npm Environmental variables path
Download Appium Server from Node
Download Appium and Selenium Java client library
Install IntelliJ – Create a Project in IntelliJ- configure Appium libraries

Start Appium Server

